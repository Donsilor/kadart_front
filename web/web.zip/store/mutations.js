export default {
  getWidth(state, val) {
    state.winWid = val
  }
}
