// import Vuex from 'vuex'
export const state = () => {
  return {
    winWid: 0
  }
}
