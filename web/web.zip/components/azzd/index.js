import Component from './index.vue'
export default {
  install(Vue) {
    Vue.component('azzd', Component)
  }
}
