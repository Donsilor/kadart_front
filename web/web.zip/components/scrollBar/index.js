import Component from './index.vue'
export default {
  install(Vue) {
    Vue.component('scrollBar', Component)
  }
}
