<template>
  <div class="container">
    <azzd></azzd>
    <goodsDetailPage></goodsDetailPage>
  </div>
</template>

<script>
import azzd from '~/components/azzd/index.vue'
import goodsDetailPage from '~/pageComponents/goodsDetailPage/index.vue'

export default {
  components: {
    azzd,
    goodsDetailPage,
  }
}
</script>

<style>
</style>
