<template>
  <div class="white-valentine-day">
    <div class="tit">Celebrate Women Power With KadArt</div>

    <div class="text">
      <div class="text-paragraph">It is always not enough to show our respect and love to all the women in our life.</div>
      <div class="text-paragraph">However, 8th of March is the perfect day to let yourself and all the strong women in your life to know they deserve the best everthing in the world.</div>
      <div class="text-paragraph">In this special day, what could be a better gift idea than a piece of delicate and meaningful jewelry?</div>
    </div>

    <div class="img-box">
      <img src="../../static/womensDay/womens-day-5.jpg" alt="">
    </div>

    <div class="text">
      <div class="text-paragraph">Here are some ideas:</div>
      <div class="text-paragraph"><a href="">Silver</a> is delicate and soft;</div>
      <div class="text-paragraph">Just like women are soft-hearted and kind,</div>
    </div>

    <div class="img-box">
      <img src="../../static/womensDay/womens-day-4.jpg" alt="">
    </div>

    <div class="explain">Classic Silver Earrings with CZ Stones</div>

    <div class="text">
      <div class="text-paragraph"><a href="">Diamond</a> is tough and determined;</div>
      <div class="text-paragraph">Just like women are brave and strong,</div>
    </div>


    <div class="img-box">
      <img src="../../static/womensDay/womens-day-2.jpg" alt="">
    </div>

    <div class="explain">Cushion diamond rings</div>

    <div class="text">
      <div class="text-paragraph"><a href="">Rose gold</a> is romantic and sentimental;</div>
      <div class="text-paragraph">Just like women are caring and lovely,</div>
    </div>

    <div class="img-box">
      <img src="../../static/womensDay/womens-day-3.jpg" alt="">
    </div>

    <div class="explain">Snowflake Diamond Necklace &amp; Rose Gold Necklace In Heart Pedent</div>

    <div class="text">
      <div class="text-paragraph">Indulge and celebrate yourself and the women you love with our Women's Day collection here!!！</div>
    </div>

    <hr>

  </div>
</template>

<script>
  export default{
    head() {
      return {
        title: 'Celebrate Women Power With Kad Art Jewelry',
        meta: [{
            hid: 'description',
            name: 'description',
            content: '8th of March is the perfect day to let yourself and all the strong women in your life to know they deserve the best everthing in the world. Some meaningful jewelry gift ideas from Kad Art.'
          },
          {
            hid: 'keywords',
            name: 'keywords',
            content: 'women\'s day gift ideas, jewelry for women, women\'s day jewelry collection'
          }
        ]
      }
    }
  }
</script>

<style>

  img{
    width: 100%;
  }
  .white-valentine-day{
    width: 800px;
    margin: 20px auto;
  }

  .white-valentine-day .tit{
    font-weight: 600;
    font-size: 24px;
    line-height: 1.22;
    margin: 24px 0 60px;
    word-wrap: break-word;
    text-align: center;
  }

  .img-1{
    margin-bottom: 24px;
  }

  .text{
    margin-top: 20px;
    font-size: 16px;
  }
  .text-paragraph{
    margin: 1.4em 0;
  }

  .text-paragraph a{
    text-decoration: underline;
  }

  .explain{
    margin-top: .66667em;
    padding: 0 1em;
    font-size: .9em;
    line-height: 1.5;
    text-align: center;
    color: #999;
  }

  hr {
      margin: 4em auto;
      width: 240px;
      max-width: 100%;
      border: none;
      border-top: 1px solid #d3d3d3;
  }
</style>
