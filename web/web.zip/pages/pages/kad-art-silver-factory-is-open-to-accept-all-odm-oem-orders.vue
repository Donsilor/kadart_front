<template>
  <div class="kad-art">
      <div id="page-header">
        <h1 id="page-title">Kad Art Factory is open to accept all ODM OEM orders!</h1>
      </div>

      <div id="col-main" class="col-md-24 normal-page clearfix">
        <div class="page   ">
        <p>&nbsp;</p>
      <p>We are back to work on Feb 10th, 2020!&nbsp;</p>
      <ul>
      <li>KadArt is <strong>resumed</strong> <strong>regular operation</strong> without being affected by the Corona Virus; our staffs and factories have <strong>returned from the holiday</strong> and the production capacity is getting <strong>recovered</strong>.</li>
      <li>We are promising there <strong>will not be any delay</strong> for the order or the shipping schedule, <strong>sample order: 10 days</strong>, <strong>mass production order: 20 days</strong> after down payment;</li>
      <li>
      <strong>Quality and Safety Guaranteed</strong>:&nbsp;Strict QC standard as we always applied;</li>
      <li>To ensure the safety of the product, <strong>disinfection procedure</strong> is taken prior to <strong>every shipment</strong>;</li>
      <li>
      <strong>Stay shoulder to shoulder</strong> with our customers, minimize losses from the epidemic.</li>
      </ul>
      <div style="text-align: left;margin-top: 14px;"><img src="../../static/kad-art-silver/Kadart-QCS-1.webp" alt="Kadart-quality-control-inspect-each-piece-jewelry-before-shipment" width="" height="" style="float: none;"></div>
      <div style="text-align: left;"></div>
      <div style="margin-bottom: 8px;"><img src="../../static/kad-art-silver/Kadart-QCS-2.webp" alt="Kadart-disinfection-each-piece-of-jewelry-by-alcohol"></div>
      <p>You can <strong><a href="mailto:james@kadart.com" title="email">email us</a></strong>&nbsp;with your specific inquiry files or drawings, we will quote you within 24 hours and ship as above.</p>
      <p>14K, 18K and <a href=""></a>, diamond jewelry and brass jewerlry are available on <a href="https://www.kadart.com">Kadart.com.</a></p>
      <p>We appreciate your trust and enjoy your wonderful experience with KadArt.</p>
        </div>
      </div>
  </div>
</template>

<script>
  export default{
    head() {
      return {
        title: 'Kad Art Factory is open to accept all ODM OEM orders',
        meta: [{
            hid: 'description',
            name: 'description',
            content: 'We are back to work on Feb 10th,2020. KadArt is resumed regular operation without being affected by the Corona Virus; our staffs and factories have returned from the holiday and the production capacity is getting recovered. Welcome all ODM OEM orders, no delay shipment, reasonable price and great service!'
          },
          {
            hid: 'keywords',
            name: 'keywords',
            content: 'Kad Art Factory Open, jewelry factory accept orders, OEM ODM jewelry orders'
          }
        ]
      }
    }
  }
</script>

<style>
  .kad-art{
    max-width: 1000px;
    margin: 25px auto 90px;
  }

  img{
    width: 100%;
  }

  #page-header {
    margin: 25px 0 25px;
  }

   h1{
     color: #202020;
     text-transform: uppercase;
     margin: 0;
     font-size: 20px;
     font-weight: 400;
     text-align: center;
   }

   ul{
     margin-bottom: 10px;
   }

   ul li {
       margin-bottom: 10px;
       list-style-position: outside;
   }

   p {
       font-size: 15px;
       margin: 0 0 10px;
       font-weight: 500;
   }
</style>
