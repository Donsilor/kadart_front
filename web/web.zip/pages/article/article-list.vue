<template>
  <div class="container">
    <azzd></azzd>

    <div class="article-wrap clf">
      <div class="article-left fl">
        <div>
          <div class="article-left-tit">{{tittle}}</div>
          <div class="article-left-box">
            <a :href="item.url" class="article-left-list" :class="active_idx == index ? 'active' : ''" v-for="(item, index) in articleTitle"
              :key="index">
              <i class="article-left-icon fl"></i>
              <span>{{item.title}}</span>
            </a>
          </div>
        </div>
      </div>

      <div class="article-right fr">
        <div class="article-right-tit">{{articleTitle[active_idx].title}}</div>
        <div class="article-right-box">
          <div class="article-right-list" v-for="(ite, index) in articleItem" @click="intoDetail(index)">
            <div class="img-box">
              <img :src="ite.img" alt="">
            </div>
            <div class="article-right-r">
              <div class="article-right-list-title">{{ite.title}}</div>
              <div class="article-right-list-text">{{ite.seo_content}}</div>
            </div>
          </div>
        </div>

        <div class="pages" v-if="page_count > 1">
          <div class="totle" v-if="total_count != 0"><span>total</span>{{total_count}}</div>
          <el-pagination
            :total="page_count"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page.sync="currentPage1"
            :page-size="1"
            layout="prev, pager, next, jumper">
          </el-pagination>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
  import azzd from '~/components/azzd/index.vue'

  export default {
    head() {
      return {
        title: this.title,
        meta: [{
          hid: 'description',
          name: 'description',
          content: this.title
        }]
      }
    },
    components: {
      azzd
    },
    data() {
      return {
        active_idx: 0,
        articleTitle: [{
          title: ''
        }],
        articleItem: [],
        article_pid: 0,
        a: 0,
        b: 0,
        detailUrl: '',
        title: '',
        tittle: '',
        currentPage1: 1,
        page_count: 0,
        total_count: 0,
        result: ''
      }
    },
    mounted() {
      document.documentElement.scrollTop = document.body.scrollTop = 0;

      this.$axios.get('/article/article-cate/index', {
        params: {}
      }).then(res => {
        this.result = res.data.data.lists ;

        this.gitClassify()
        this.getList()

      }).catch(function(error) {
        console.log(error);
      });
    },
    methods: {
      gitClassify(){
        var that = this;

        var url_id,path = location.href;
        if(path.indexOf('?') != -1){
          url_id = path.split('=')[1];
        }else{
          url_id = path.slice(path.lastIndexOf('/')+1);
        }


        // 文章分类
        var articleList = this.result;
        var flag = false;

        for (var i = 0; i < articleList.length; i++) {
          for (var j = 0; j < articleList[i].items.length; j++) {
            for (var k = 0; k < articleList[i].items[j].items.length; k++) {
              var list = articleList[i].items[j].items[k];
              // console.log(list)

              if (list.id == url_id) {
                that.a = i;
                that.b = j;
                that.active_idx = k;
                that.article_pid = list.id;
                that.title = articleList[i].items[j].items[k].title,
                that.tittle = articleList[i].items[j].title;
                flag = true;
                break;
              } else {
                // 跳转404
                // console.log(222)
              }
            }

            if (flag) {
              break;
            }
          }

          if (flag) {
            break;
          }
        }

        this.articleTitle = articleList[this.a].items[this.b].items;
      },
      intoDetail(k) {
        // var that = this;
        // localStorage.setItem('articleId', that.articleItem[k].id)
        // location.href = '/article/article-detail';

        // console.log(this.articleItem[k].url)
        location.href = this.articleItem[k].url;
      },

      // chooseItem(k) {
        // this.active_idx = k;
        // this.article_pid = this.articleTitle[k].id;
        // this.getList();

        // var urlA = this.$refs.list[k].getElementsByTagName('span')[0].innerText.replace(' ', '-');
        // location.href = '/' + urlA;
        // console.log(urlA)
      // },

      // 文章列表
      getList(k) {
        var that = this;
        var i = 1;
        if(k){
          i = k;
        }
        this.$axios.get('/article/article/search', {
          params: {
            'pid': that.article_pid,
            'page_size': 5,
            'page': i
          }
        }).then(res => {
          this.articleItem = res.data.data.data;
          this.total_count = res.data.data.total_count;
          this.page_count = res.data.data.page_count;

          console.log(this.articleItem)
        }).catch(function(error) {
          console.log(error);
        });
      },
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`);

        this.getList(val)
      }
    }
  }
</script>

<style scoped>
  .article-right-list-text {
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 3;
    overflow: hidden;
  }

  .article-detail-box p {
    font-size: 14px;
    line-height: 28px;
    color: #666;
    box-sizing: border-box;
    text-align: left;
  }

  .article-detail-box img {
    max-width: 720px;
    margin: 30px 0;
  }

  .article-right .img-box {
    width: 140px;
    height: 140px;
    position: relative;
    overflow: hidden;
    flex-shrink: 0;
  }

  .article-right .img-box img {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    max-width: 100%;
    max-height: 100%;
    width: auto;
  }

  .article-right-list {
    cursor: pointer;
    display: flex;
    align-items: center;
    padding: 30px 0;
  }

  .article-right-r {
    width: calc(100% - 160px);
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    margin-left: 20px;
    height: 140px;
    padding: 3px 0;
    box-sizing: border-box;
    flex-shrink: 0;
  }

  .article-right-list-title {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .pages{
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 120px;
  }
  .totle{
    margin-right: 24px;
    font-weight: 400;
    color: #606266;
  }
  .totle span{
    margin-right: 14px;
  }
</style>
