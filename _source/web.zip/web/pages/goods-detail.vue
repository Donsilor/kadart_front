<template>
  <div class="container">
    <menus></menus>
    <headers></headers>
    <navs></navs>
    <ad></ad>
    <goodsDetailPage></goodsDetailPage>
    <footers></footers>
    <scroll></scroll>
  </div>
</template>

<script>
import menus from '~/components/Menu.vue'
import headers from '~/components/Header.vue'
import navs from '~/components/Nav.vue'
import ad from '~/components/Ad.vue'
import goodsDetailPage from '~/components/GoodsDetailPage.vue'
import footers from '~/components/Footer.vue'
import scroll from '~/components/Scroll.vue'

export default {
  data(){
    return{
    }
  },
  components: {
    menus,
    headers,
    navs,
    ad,
    goodsDetailPage,
    footers,
    scroll
  }
}
</script>

<style>
</style>
